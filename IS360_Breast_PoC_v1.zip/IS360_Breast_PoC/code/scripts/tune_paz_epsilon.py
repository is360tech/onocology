"""Pick a PAZ epsilon per task, EMPIRICALLY, from DEV out-of-fold predictions -- never on MS.
  python bc.py tune-paz --dev-exp exp_<your_DEV_id>
Reads workspace/research/tenant=is360/experiments/<dev-exp>/oof/<task>__P4__slda.csv (produced by
`bc.py experiments --partition DEV`) and writes the same folder's paz_thresholds.json: one
{method, epsilon} per task, auto-selecting margin for 2-class tasks and entropy for 3+ class tasks.
"""
import os, sys, json, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np, pandas as pd
import config as C
from models import select_epsilon

def load_oof(exp_dir, task):
    f = os.path.join(exp_dir, "oof", f"{task}__{C.PRIMARY_VARIANT}__{C.PRIMARY_MODEL}.csv")
    if not os.path.exists(f): raise SystemExit(f"missing {f} -- run `bc.py experiments --partition DEV` first")
    df = pd.read_csv(f); p_cols = [c for c in df.columns if c.startswith("p_")]
    classes = [c[2:] for c in p_cols]; ycol = "y_true" if "y_true" in df.columns else "y"
    return df[p_cols].values, df[ycol].values, classes

def main(exp_dir, target_coverage):
    out = {}
    for task in C.TASKS:
        proba, y, classes = load_oof(exp_dir, task); K = len(classes); method = "margin" if K == 2 else "entropy"
        eps, acc_conf, cov = select_epsilon(proba, y, classes, method=method, target_coverage=target_coverage)
        out[task] = dict(method=method, epsilon=round(eps, 4), n_classes=K, selected_on="DEV",
                         acc_confident_at_selection=round(acc_conf, 4) if np.isfinite(acc_conf) else None,
                         coverage_at_selection=round(cov, 4) if np.isfinite(cov) else None)
        tail = f"acc_confident={acc_conf:.3f}  coverage={cov:.3f}" if np.isfinite(acc_conf) else f"(no grid point met target_coverage={target_coverage})"
        print(f"{task:<22} K={K}  method={method:<7} epsilon={eps:.3f}  {tail}")
    outp = os.path.join(exp_dir, "paz_thresholds.json"); json.dump(out, open(outp, "w"), indent=2)
    print(f"\nwrote {outp}")
    print("\nNext step (do this BEFORE touching MS again):")
    print("  1. Paste the {method, epsilon} per task above into docs/protocol.yaml under 'uncertainty: per_task:'.")
    print("  2. python bc.py protocol        # re-freezes protocol.yaml -- this changes the protocol hash")
    print("  3. Any `experiments --partition MS` run after that is a NEW confirmatory run under a NEW protocol")
    print("     hash. Report both protocol hashes in the manuscript -- do not silently replace the already-")
    print("     reported numbers from the first confirmatory run.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--dev-exp", required=True, help="experiment id, e.g. exp_20260926_001_DEV")
    ap.add_argument("--target-coverage", type=float, default=0.5); a = ap.parse_args()
    exp_dir = os.path.join(C.RESEARCH, "experiments", a.dev_exp)
    main(exp_dir, a.target_coverage)
