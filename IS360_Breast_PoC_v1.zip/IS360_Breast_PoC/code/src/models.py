"""Models: NeuroSync SLDA (Tikhonov-regularised LDA), baselines (logistic regression, RBF-SVM, random forest), PAZ ambiguity gate."""
import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.utils.validation import check_X_y, check_array, check_is_fitted
from sklearn.utils.multiclass import unique_labels
import config as C

class NeuroSyncSLDA(ClassifierMixin, BaseEstimator):
    # NOTE: ClassifierMixin MUST precede BaseEstimator in this list (not the reverse, which this class used
    # to have). Since scikit-learn's 1.6 tags refactor, __sklearn_tags__() resolution is order-dependent:
    # with BaseEstimator first, ClassifierMixin's estimator_type="classifier" tag never propagates, and any
    # sklearn-internal code that checks the tag (e.g. CalibratedClassifierCV) sees this as a non-classifier
    # and raises "... Got a regressor ..." -- found by actually running slda_cal through CalibratedClassifierCV,
    # not by compiling. Direct .fit()/.predict()/.predict_proba() calls were unaffected by this bug, which is
    # why it was invisible until calibration (a tag-aware sklearn meta-estimator) was added.
    """Pooled within-class covariance S_W + lam*I (NeuroSync SLDA, Tikhonov regularisation). Inputs must be standardised.
    uniform_priors=True uses equal class priors (balanced decision rule for imbalanced tasks)."""
    def __init__(self, lam=1.0, uniform_priors=True): self.lam = lam; self.uniform_priors = uniform_priors

    def fit(self, X, y):
        X, y = check_X_y(X, y); self.classes_ = unique_labels(y); p = X.shape[1]
        self.means_ = np.vstack([X[y == c].mean(0) for c in self.classes_])
        Sw = sum(((X[y == c] - m).T @ (X[y == c] - m)) for c, m in zip(self.classes_, self.means_)) / max(len(y) - len(self.classes_), 1)
        pri = np.full(len(self.classes_), 1.0 / len(self.classes_)) if self.uniform_priors else np.array([(y == c).mean() for c in self.classes_])
        self.coef_ = np.linalg.solve(Sw + self.lam * np.eye(p), self.means_.T).T
        self.intercept_ = -0.5 * np.einsum("kp,kp->k", self.means_, self.coef_) + np.log(pri); return self

    def decision_function(self, X): check_is_fitted(self); return check_array(X) @ self.coef_.T + self.intercept_
    def predict_proba(self, X):
        s = self.decision_function(X); s = s - s.max(1, keepdims=True); e = np.exp(s); return e / e.sum(1, keepdims=True)
    def predict(self, X): return self.classes_[self.decision_function(X).argmax(1)]

def make_model(name, seed=C.SEED):
    """-> (sklearn Pipeline, param grid for the inner CV or None)."""
    pre = [("imp", SimpleImputer(strategy="median")), ("var", VarianceThreshold(0.0)), ("sc", StandardScaler())]
    if name == "slda": return Pipeline(pre + [("clf", NeuroSyncSLDA())]), {"clf__lam": C.LAMBDA_GRID}
    if name == "logreg": return Pipeline(pre + [("clf", LogisticRegression(class_weight="balanced", max_iter=3000))]), {"clf__C": [0.01, 0.1, 1.0, 10.0]}
    if name == "svm": return Pipeline(pre + [("clf", SVC(kernel="rbf", probability=True, class_weight="balanced", random_state=seed))]), {"clf__C": [0.1, 1.0, 10.0]}
    if name == "rf": return Pipeline(pre + [("clf", RandomForestClassifier(n_estimators=300, min_samples_leaf=2, class_weight="balanced_subsample", random_state=seed, n_jobs=1))]), None
    if name == "slda_cal":
        return Pipeline(pre + [("clf", CalibratedSLDA())]), {"clf__lam": C.LAMBDA_GRID}
    raise ValueError(name)


class CalibratedSLDA(ClassifierMixin, BaseEstimator):  # mixin before BaseEstimator -- see NeuroSyncSLDA's note above
    """Platt-scaling (sigmoid) calibration of NeuroSyncSLDA, implemented directly rather than through
    sklearn.calibration.CalibratedClassifierCV. That meta-estimator assumes a binary classifier's raw
    predictions collapse to one column (n_samples, 1); NeuroSyncSLDA's predict_proba returns the full
    (n_samples, n_classes) matrix for binary problems too -- the same convention scikit-learn's own
    LogisticRegression.predict_proba uses -- which breaks CalibratedClassifierCV's internal label-binarize
    indexing (confirmed by actually running it: "IndexError: index 1 is out of bounds for axis 1 with size 1").
    This wrapper fits one sigmoid calibrator per class on a held-out slice of the TRAINING fold only (never
    the test fold, via calib_fraction split before NeuroSyncSLDA itself is fit), which is the same idea
    CalibratedClassifierCV implements, without depending on its binary-specific shape assumption."""
    def __init__(self, lam=1.0, calib_fraction=0.3, random_state=None):
        self.lam = lam; self.calib_fraction = calib_fraction; self.random_state = random_state

    def fit(self, X, y):
        X, y = check_X_y(X, y)
        seed = self.random_state if self.random_state is not None else C.SEED
        sss = StratifiedShuffleSplit(n_splits=1, test_size=self.calib_fraction, random_state=seed)
        fit_idx, cal_idx = next(sss.split(X, y))
        self.base_ = NeuroSyncSLDA(lam=self.lam).fit(X[fit_idx], y[fit_idx]); self.classes_ = self.base_.classes_
        raw = self.base_.predict_proba(X[cal_idx]); self.calibrators_ = []
        for k in range(len(self.classes_)):
            yk = (y[cal_idx] == self.classes_[k]).astype(int)
            if len(np.unique(yk)) < 2:   # degenerate calibration slice (rare with small cohorts); fall back to raw for this class
                self.calibrators_.append(None); continue
            lr = LogisticRegression(max_iter=1000); lr.fit(raw[:, [k]], yk); self.calibrators_.append(lr)
        return self

    def predict_proba(self, X):
        check_is_fitted(self); raw = self.base_.predict_proba(check_array(X)); out = np.zeros_like(raw)
        for k, lr in enumerate(self.calibrators_):
            out[:, k] = lr.predict_proba(raw[:, [k]])[:, 1] if lr is not None else raw[:, k]
        s = out.sum(1, keepdims=True); s[s == 0] = 1.0; return out / s   # renormalise to a valid simplex

    def predict(self, X): return self.classes_[self.predict_proba(X).argmax(1)]

def margin_score(proba):
    """Top-1 minus top-2 posterior probability. Confidence score: HIGH = confident, LOW = ambiguous.
    Binary-oriented: for 3+ classes it ignores all probability mass below the top two, which is the
    specific weakness that produced a non-monotonic PAZ coverage-accuracy curve on density_img (3-class)."""
    s = np.sort(proba, axis=1); return s[:, -1] - s[:, -2]

def entropy_score(proba, eps=1e-12):
    """Normalized Shannon entropy of the FULL posterior, scaled to [0, 1] by log(K).
    Uncertainty score: LOW = confident (near one-hot), HIGH = ambiguous (near uniform). Uses every class's
    probability, so it is the natural choice once K > 2 -- note the comparison direction is OPPOSITE of
    margin_score (high entropy = ambiguous, not low)."""
    p = np.clip(proba, eps, 1.0); H = -(p * np.log(p)).sum(axis=1); K = proba.shape[1]; return H / np.log(K)

def paz_gate(proba, epsilon=None, method="auto"):
    """PAZ ambiguity gate. method: 'margin' | 'entropy' | 'auto' (margin for 2-class, entropy for 3+ class,
    resolved from proba.shape[1]). Returns (score, is_ambiguous, method_used) -- method_used is always
    returned explicitly because 'auto' resolves silently otherwise."""
    K = proba.shape[1]; resolved = ("margin" if K == 2 else "entropy") if method == "auto" else method
    if resolved == "margin":
        eps = C.PAZ_EPSILON if epsilon is None else epsilon; score = margin_score(proba); return score, score < eps, resolved
    elif resolved == "entropy":
        eps = C.PAZ_EPSILON_ENTROPY if epsilon is None else epsilon; score = entropy_score(proba); return score, score > eps, resolved
    raise ValueError(f"unknown PAZ method: {method}")

def select_epsilon(proba, y, classes, method="margin", target_coverage=0.5, grid=None):
    """Pick epsilon EMPIRICALLY from held-out (e.g. DEV out-of-fold) probabilities: the threshold that
    maximises accuracy among confident predictions, subject to covering >= target_coverage of cases.
    Always call this per task, on DEV data only, before freezing a value into protocol.yaml -- the entropy
    scale does not carry margin intuition (a fairly confident 3-class [0.7,0.2,0.1] already has normalized
    entropy ~0.73)."""
    classes = np.asarray(classes)
    if grid is None: grid = np.linspace(0.05, 0.45, 9) if method == "margin" else np.linspace(0.30, 0.95, 14)
    pred = classes[proba.argmax(1)]; best = None
    for eps in grid:
        _, amb, _ = paz_gate(proba, eps, method); conf = ~amb; cov = float(conf.mean())
        if cov < target_coverage or conf.sum() == 0: continue
        acc = float((pred[conf] == y[conf]).mean())
        if best is None or acc > best[1]: best = (float(eps), acc, cov)
    return best if best is not None else (float(grid[len(grid) // 2]), float("nan"), float("nan"))

def paz_task_validity(observed_auc, permuted_auc_ci):
    """Null guard: False when observed_auc is NOT distinguishable from the permutation-control null range.
    When False, the PAZ coverage-accuracy curve for that task should carry a 'not meaningful' annotation --
    posterior margin/entropy cannot be expected to track correctness when there is no real decision boundary."""
    lo, hi = permuted_auc_ci; return not (lo <= observed_auc <= hi)

def paz_sweep(y, proba, classes, method="auto", grid=None):
    """Sweep epsilon across its natural [0, 1] range and return (coverage[], acc_confident[]) arrays -- the
    full coverage-accuracy curve, shared by s4_experiments.py (for aurc()) and s5_report.py (for the figure),
    so both read the exact same curve rather than two independently-coded sweeps that could silently diverge."""
    if grid is None: grid = np.linspace(0.0, 1.0, 21)
    cov, acc = [], []
    for eps in grid:
        s = paz_summary(y, proba, classes, epsilon=float(eps), method=method)
        cov.append(s["coverage"]); acc.append(s["acc_confident"])
    return np.array(cov), np.array(acc)

def paz_summary(y, proba, classes, epsilon=None, limit=C.PAZ_RATIO_LIMIT, method="auto"):
    score, amb, used = paz_gate(proba, epsilon, method); pred = np.asarray(classes)[proba.argmax(1)]; y = np.asarray(y); conf = ~amb
    return dict(method=used, epsilon=(epsilon if epsilon is not None else (C.PAZ_EPSILON if used == "margin" else C.PAZ_EPSILON_ENTROPY)),
                paz_ratio=float(amb.mean()), batch_state="AMBIGUOUS" if amb.mean() > limit else "STABLE", coverage=float(conf.mean()),
                acc_all=float((pred == y).mean()), acc_confident=float((pred[conf] == y[conf]).mean()) if conf.any() else float("nan"))
