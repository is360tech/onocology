"""Repeated, nested, patient-grouped cross-validation; metrics; patient-level bootstrap; paired comparisons; calibration."""
import numpy as np
from joblib import Parallel, delayed
from sklearn.model_selection import StratifiedGroupKFold, GridSearchCV
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, f1_score, brier_score_loss
import config as C
from models import make_model

def _align(P, mclasses, classes):
    full = np.zeros((P.shape[0], len(classes))); cl = list(classes)
    for j, c in enumerate(mclasses): full[:, cl.index(c)] = P[:, j]
    return full

def cv_repeat(X, y, groups, model_name, seed, n_splits=C.N_SPLITS, inner=C.INNER_SPLITS):
    classes = np.unique(y); P = np.zeros((len(y), len(classes))); picks = []
    per_class = min(len(set(groups[y == c])) for c in classes); k = max(2, min(n_splits, per_class)); ki = max(2, min(inner, per_class - 1))
    outer = StratifiedGroupKFold(k, shuffle=True, random_state=seed)
    for tr, te in outer.split(X, y, groups):
        assert set(groups[tr]).isdisjoint(groups[te]), "patient leakage between train and test"
        est, grid = make_model(model_name, seed)
        if grid:
            cvs = list(StratifiedGroupKFold(ki, shuffle=True, random_state=seed).split(X[tr], y[tr], groups[tr]))
            gs = GridSearchCV(est, grid, cv=cvs, scoring="balanced_accuracy", refit=True, error_score=0.0); gs.fit(X[tr], y[tr]); m = gs.best_estimator_; picks.append(gs.best_params_)
        else: m = est.fit(X[tr], y[tr])
        P[te] = _align(m.predict_proba(X[te]), m.classes_, classes)
    return P, picks

def run_cv(X, y, groups, model_name, seed=C.SEED, n_repeats=C.N_REPEATS, n_jobs=1):
    res = Parallel(n_jobs=n_jobs)(delayed(cv_repeat)(X, y, groups, model_name, seed + r) for r in range(n_repeats))
    return np.stack([r[0] for r in res]), np.unique(y), [r[1] for r in res]

_trapz = getattr(np, "trapezoid", None) or np.trapz  # np.trapz was removed in NumPy 2.0, renamed trapezoid;
                                                       # requirements.txt does not pin a NumPy version, so
                                                       # support both rather than assume one.

def aurc(coverage, accuracy):
    """Area under the (coverage, accuracy-on-covered-cases) rejection curve, via trapezoidal integration over
    coverage in [0, 1]. A single number summarising PAZ gate quality across its whole threshold sweep, instead
    of reading the shape of the curve by eye. Pair with aurc_baseline() below -- a gate adds no value if its
    AURC does not exceed the flat line at the task's own unfiltered accuracy."""
    order = np.argsort(coverage)
    return float(_trapz(np.array(accuracy)[order], np.array(coverage)[order]))

def aurc_baseline(acc_all):
    """AURC of a gate that rejects uniformly at random, independent of confidence: accuracy on the retained
    set has the same expectation as the full set at every coverage level, so the curve is flat at acc_all and
    its area is simply acc_all * 1. A real gate's AURC should exceed this to be worth using."""
    return float(acc_all)

def ece(yb, p, bins=10):
    edges = np.linspace(0, 1, bins + 1); tot = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        s = (p >= a) & (p < b if b < 1 else p <= b)
        if s.any(): tot += s.mean() * abs(yb[s].mean() - p[s].mean())
    return float(tot)

def metrics(y, P, classes, positive=None):
    y = np.asarray(y); classes = np.asarray(classes); pred = classes[P.argmax(1)]
    out = dict(acc=float((pred == y).mean()), bal_acc=float(balanced_accuracy_score(y, pred)), f1_macro=float(f1_score(y, pred, average="macro")))
    if len(np.unique(y)) < 2: return {**out, "auc": float("nan")}
    if len(classes) == 2:
        j = list(classes).index(positive); yb = (y == positive).astype(int); p = P[:, j]
        out.update(auc=float(roc_auc_score(yb, p)), sens=float(((pred == positive) & (yb == 1)).sum() / max(yb.sum(), 1)),
                   spec=float(((pred != positive) & (yb == 0)).sum() / max((1 - yb).sum(), 1)), brier=float(brier_score_loss(yb, p)), ece=ece(yb, p))
    else:
        present = [c for c in classes if (y == c).any()]
        out["auc"] = float(roc_auc_score(y, P, multi_class="ovr", labels=classes, average="macro")) if len(present) == len(classes) else float("nan")
    return out

def boot_ci(y, P, groups, fn, n_boot=C.N_BOOT, seed=C.SEED, alpha=0.05):
    """Patient-level bootstrap percentile CI of fn(y, P)."""
    rng = np.random.default_rng(seed); ug = np.unique(groups); idx = {g: np.where(groups == g)[0] for g in ug}; vals = []
    for _ in range(n_boot):
        ii = np.concatenate([idx[g] for g in rng.choice(ug, len(ug))]); 
        if len(np.unique(y[ii])) < 2: continue
        v = fn(y[ii], P[ii])
        if np.isfinite(v): vals.append(v)
    return (float(np.percentile(vals, 100 * alpha / 2)), float(np.percentile(vals, 100 * (1 - alpha / 2)))) if len(vals) > 20 else (float("nan"), float("nan"))

def paired_boot(y, P1, P2, groups, fn, n_boot=C.N_BOOT, seed=C.SEED):
    """Paired patient-level bootstrap of fn(P1) - fn(P2) on identical samples. Returns (delta, lo, hi, two-sided p)."""
    rng = np.random.default_rng(seed); ug = np.unique(groups); idx = {g: np.where(groups == g)[0] for g in ug}; d = []
    for _ in range(n_boot):
        ii = np.concatenate([idx[g] for g in rng.choice(ug, len(ug))])
        if len(np.unique(y[ii])) < 2: continue
        a, b = fn(y[ii], P1[ii]), fn(y[ii], P2[ii])
        if np.isfinite(a) and np.isfinite(b): d.append(a - b)
    d = np.array(d); 
    if len(d) < 20: return (float("nan"),) * 4
    p = 2 * min((d <= 0).mean(), (d >= 0).mean()); return float(fn(y, P1) - fn(y, P2)), float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)), float(min(p, 1.0))
