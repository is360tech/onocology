Place the MIAS download here (input only): archive.zip, or all-mias_tar.gz, or an extracted all-mias folder.
